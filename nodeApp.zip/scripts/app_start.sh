#!/bin/bash
cd /home/ec2-user/Share-e-care-Nodejs
pm2 start server.js -i max
